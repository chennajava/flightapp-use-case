package com.flightapp.model;

public class PnrSearch {
	
	private Integer pnr;
	
	

	public PnrSearch() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getPnr() {
		return pnr;
	}

	public void setPnr(Integer pnr) {
		this.pnr = pnr;
	}
	
	

}
