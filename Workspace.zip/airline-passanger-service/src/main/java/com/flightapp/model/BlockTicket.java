package com.flightapp.model;

public class BlockTicket {
	
	private Integer Flight_id;
	private String comment;
	
	public BlockTicket() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Integer getFlight_id() {
		return Flight_id;
	}
	public void setFlight_id(Integer flight_id) {
		Flight_id = flight_id;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	

	

}
