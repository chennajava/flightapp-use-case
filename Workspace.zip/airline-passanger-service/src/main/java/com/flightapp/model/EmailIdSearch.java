package com.flightapp.model;

public class EmailIdSearch {
	
	private String email_id;

	
	
	public EmailIdSearch() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getEmail_id() {
		return email_id;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	
	

}
