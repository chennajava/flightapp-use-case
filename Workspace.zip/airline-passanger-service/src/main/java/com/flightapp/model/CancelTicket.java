package com.flightapp.model;

public class CancelTicket {
	
	private Integer pnr;
	private String comment;
	
	

	public CancelTicket() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	public String getComment() {
		return comment;
	}



	public void setComment(String comment) {
		this.comment = comment;
	}



	public Integer getPnr() {
		return pnr;
	}

	public void setPnr(Integer pnr) {
		this.pnr = pnr;
	}
	
	

}
