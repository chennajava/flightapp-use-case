package com.flightapp.model;

//To block or unblock flight
public class StatusUpdate {
	
	private Integer flight_id;
	private String comment;
	
	
	
	public StatusUpdate() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Integer getFlight_id() {
		return flight_id;
	}

	public void setFlight_id(Integer flight_id) {
		this.flight_id = flight_id;
	}

	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	
	

}
