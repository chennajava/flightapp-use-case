package com.flightapp.exception;

public class AdminException extends Exception {

	public AdminException() {
		super();
	}
	
	public AdminException(String m) {
		super(m);
	}
	
	public AdminException(Exception e) {
		super(e);
	}
	
	public AdminException(String m, Exception e) {
		super(m, e);
	}
	
	

}
